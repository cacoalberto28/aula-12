# 12-Processos-ARIMA
Processos autorregressivos integrados de médias móveis
